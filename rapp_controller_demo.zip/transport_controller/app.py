from flask import Flask, request, jsonify
import subprocess, shlex, os

app = Flask(__name__)
XHAUL_IFACE = os.environ.get("XHAUL_IFACE", "eth1")
ROOT_HANDLE = "1:"
CLASSES = {"urlcc": "1:10", "embb": "1:20"}

def run(cmd):
    return subprocess.run(shlex.split(cmd), capture_output=True, text=True)

def tc_reset():
    run(f"tc qdisc del dev {XHAUL_IFACE} root")
    run(f"tc qdisc add dev {XHAUL_IFACE} root handle {ROOT_HANDLE} htb default 20")
    run(f"tc class add dev {XHAUL_IFACE} parent 1: classid 1:1 htb rate 10gbit ceil 10gbit")

def ensure_class(name, rate, ceil):
    cls = CLASSES[name]
    run(f"tc class replace dev {XHAUL_IFACE} parent 1:1 classid {cls} htb rate {rate} ceil {ceil}")
    handle = cls.replace(':','')
    run(f"tc qdisc replace dev {XHAUL_IFACE} parent {cls} handle {handle}: fq_codel ecn")

def attach_filters(vlan, dscp, classid):
    run(f"tc filter del dev {XHAUL_IFACE} protocol ip parent 1:")
    run(f"tc filter del dev {XHAUL_IFACE} protocol 802.1Q parent 1:")
    run(f"tc filter add dev {XHAUL_IFACE} parent 1: protocol 802.1Q flower vlan_id {vlan} action pass")
    dsfield = int(dscp) << 2
    run(f"tc filter add dev {XHAUL_IFACE} parent 1: protocol ip u32 match ip dsfield 0x{dsfield:02x} 0xff flowid {classid}")

@app.route('/apply_policy', methods=['POST'])
def apply_policy():
    body = request.get_json(force=True)
    if body.get('reset', False):
        tc_reset()
    slices = body.get('slices', [])
    applied = []
    for s in slices:
        name = s['name'].lower()
        if name not in CLASSES:
            return jsonify({'error': f'unknown slice {name}'}), 400
        vlan = int(s['vlan']); dscp = int(s['dscp'])
        rate = s.get('rate','100mbit'); ceil = s.get('ceil','10gbit')
        ensure_class(name, rate, ceil)
        attach_filters(vlan, dscp, CLASSES[name])
        applied.append({'name':name,'vlan':vlan,'dscp':dscp,'rate':rate,'ceil':ceil})
    return jsonify({'status':'ok','iface':XHAUL_IFACE,'applied':applied})

@app.route('/tc_show', methods=['GET'])
def tc_show():
    qdisc = run(f"tc -s qdisc show dev {XHAUL_IFACE}").stdout
    classes = run(f"tc -s class show dev {XHAUL_IFACE}").stdout
    filters = run(f"tc filter show dev {XHAUL_IFACE} parent 1:").stdout
    return jsonify({'iface':XHAUL_IFACE,'qdisc':qdisc,'classes':classes,'filters':filters})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)
