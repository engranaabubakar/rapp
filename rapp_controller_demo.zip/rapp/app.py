from flask import Flask, request, jsonify
import os, time, requests

app = Flask(__name__)
TRANSPORT_CTRL = os.environ.get("TRANSPORT_CTRL", "http://127.0.0.1:8080/apply_policy")
DELAY_THR = float(os.environ.get("DELAY_THR_MS", "0.95"))
JITTER_THR = float(os.environ.get("JITTER_THR_MS", "0.8"))
URLLC_IDLE_THR = float(os.environ.get("URLLC_IDLE_G", "0.5"))
EMBB_DEMAND_THR = float(os.environ.get("EMBB_DEMAND_G", "7.0"))
MIN_HOLD = float(os.environ.get("MIN_HOLD_S", "3.0"))

STATE = {"mode": "baseline", "last_change": 0.0}

def push_policy(urlcc_rate, embb_rate):
    body = {
        "reset": True,
        "slices":[
          {"name":"urlcc","vlan":100,"dscp":46,"rate":urlcc_rate,"ceil":"10gbit"},
          {"name":"embb","vlan":200,"dscp":0,"rate":embb_rate,"ceil":"10gbit"}
        ]
    }
    r = requests.post(TRANSPORT_CTRL, json=body, timeout=5)
    r.raise_for_status()
    return r.json()

@app.route("/ingest", methods=["POST"])
def ingest():
    t = request.get_json(force=True)
    jitter = float(t.get("jitter_ms", 0.0))
    delay  = float(t.get("delay_ms", 0.0))
    embb   = float(t.get("embb_demand_gbps", 0.0))
    urlcc  = float(t.get("urllc_load_gbps", 0.0))

    now = time.time()
    if now - STATE["last_change"] < MIN_HOLD:
        return jsonify({"status":"hold","mode":STATE["mode"]})

    if delay > DELAY_THR or jitter > JITTER_THR:
        STATE["mode"] = "protect_urlcc"
        STATE["last_change"] = now
        res = push_policy("2gbit","6gbit")
        return jsonify({"status":"applied","mode":STATE["mode"],"tc":res})

    if urlcc < URLLC_IDLE_THR and embb >= EMBB_DEMAND_THR:
        STATE["mode"] = "borrow_to_embb"
        STATE["last_change"] = now
        res = push_policy("1gbit","8gbit")
        return jsonify({"status":"applied","mode":STATE["mode"],"tc":res})

    STATE["mode"] = "baseline"
    STATE["last_change"] = now
    res = push_policy("2gbit","6gbit")
    return jsonify({"status":"applied","mode":STATE["mode"],"tc":res})

@app.route("/decide", methods=["POST"])
def decide():
    m = request.get_json(force=True).get("mode","baseline")
    if m == "protect":
        res = push_policy("2gbit","6gbit")
    elif m == "borrow":
        res = push_policy("1gbit","8gbit")
    else:
        res = push_policy("2gbit","6gbit")
    STATE["mode"] = m
    STATE["last_change"] = time.time()
    return jsonify({"status":"applied","mode":m,"tc":res})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8090)
